from django.apps import AppConfig


class Prilog01Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'prilog01'
